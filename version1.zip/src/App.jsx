import { useEffect, useState } from 'react';
import { Link, NavLink, Outlet, Route, Routes, useLocation } from 'react-router-dom';

function useSectionReveal(trigger) {
  useEffect(() => {
    const nodes = Array.from(document.querySelectorAll('.section-reveal'));
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15 }
    );

    nodes.forEach((node) => {
      node.classList.remove('is-visible');
      observer.observe(node);
    });

    return () => observer.disconnect();
  }, [trigger]);
}

function SiteLayout() {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  useSectionReveal(location.pathname);

  useEffect(() => {
    setMenuOpen(false);
    window.scrollTo(0, 0);
  }, [location.pathname]);

  return (
    <>
      <div className="grain" />
      <header className="site-header">
        <Link className="brand" to="/" aria-label="DnD Digital home">
          <img src="/assets/logo_500px_500px_white.svg" alt="DnD Digital logo" />
          <span>DnD Digital</span>
        </Link>
        <button
          className="menu-toggle"
          aria-expanded={menuOpen}
          aria-controls="main-nav"
          onClick={() => setMenuOpen((value) => !value)}
        >
          Menu
        </button>
        <nav id="main-nav" className={`main-nav ${menuOpen ? 'open' : ''}`}>
          <NavLink to="/" end>
            Home
          </NavLink>
          <NavLink to="/about">About</NavLink>
          <NavLink to="/services">Services</NavLink>
          <NavLink to="/services/generative-ai">Generative AI</NavLink>
          <NavLink to="/contact">Contact</NavLink>
        </nav>
      </header>

      <main>
        <Outlet />
      </main>

      <footer className="site-footer">
        <img src="/assets/logo_500px_500px_black.svg" alt="DnD Digital logo" />
        <p>© {new Date().getFullYear()} DnD Digital. Practical AI. Real outcomes.</p>
      </footer>
    </>
  );
}

function HomePage() {
  return (
    <>
      <section className="hero section-reveal">
        <div className="hero-copy">
          <p className="eyebrow">AI Engineering Partner</p>
          <h1>
            Build <span>smarter operations</span>
            with practical AI and custom software.
          </h1>
          <p className="lead">
            We design, implement, and support AI-first systems that reduce repetitive work,
            unlock new revenue, and give teams better decision speed.
          </p>
          <div className="hero-actions">
            <Link className="btn btn-primary" to="/contact">
              Book a 15-min call
            </Link>
            <Link className="btn btn-ghost" to="/services">
              Explore services
            </Link>
          </div>
        </div>

        <aside className="hero-panel">
          <h2>What matters to us</h2>
          <ul>
            <li>Measurable ROI before hype</li>
            <li>AI that fits your real workflows</li>
            <li>Delivery from strategy to launch</li>
          </ul>
          <div className="panel-stat-grid">
            <article>
              <h3>50+</h3>
              <p>Projects delivered</p>
            </article>
            <article>
              <h3>100%</h3>
              <p>Client satisfaction focus</p>
            </article>
            <article>
              <h3>24/7</h3>
              <p>Operational support</p>
            </article>
          </div>
        </aside>
      </section>

      <section className="services section-reveal">
        <header className="section-head">
          <p className="eyebrow">Services</p>
          <h2>Capabilities built for execution</h2>
        </header>
        <div className="card-grid">
          <article className="service-card">
            <img src="/assets/chatgpt_interface.webp" alt="Generative AI service" />
            <div>
              <h3>Generative AI & Agents</h3>
              <p>
                From RAG pipelines to autonomous workflows, we build intelligent systems that can
                reason, retrieve, and act across your business.
              </p>
              <Link className="link-arrow" to="/services/generative-ai">
                View service
              </Link>
            </div>
          </article>
          <article className="service-card">
            <img src="/assets/consulting.jpg" alt="AI consulting service" />
            <div>
              <h3>AI Consulting & Strategy</h3>
              <p>
                We map high-value opportunities, de-risk implementation, and create a roadmap your
                leadership team can execute with confidence.
              </p>
              <Link className="link-arrow" to="/services/consulting">
                View service
              </Link>
            </div>
          </article>
          <article className="service-card">
            <img src="/assets/software.webp" alt="Custom software service" />
            <div>
              <h3>Bespoke Software Development</h3>
              <p>
                Modern web applications, integrations, and scalable cloud architecture tailored to
                your operations and growth goals.
              </p>
              <Link className="link-arrow" to="/services/software">
                View service
              </Link>
            </div>
          </article>
        </div>
      </section>

      <section className="approach section-reveal">
        <header className="section-head">
          <p className="eyebrow">Why DnD</p>
          <h2>Expertise, innovation, results, partnership</h2>
        </header>
        <div className="pillars">
          <article>
            <p className="tag">Expertise</p>
            <h3>Deep technical delivery</h3>
            <p>
              We combine LLM architecture, software engineering, and automation know-how to deliver
              production-ready systems.
            </p>
          </article>
          <article>
            <p className="tag">Innovation</p>
            <h3>Future-ready solutions</h3>
            <p>
              Every solution is designed for adaptability so your team can evolve as AI tooling and
              market expectations move.
            </p>
          </article>
          <article>
            <p className="tag">Results</p>
            <h3>Impact you can track</h3>
            <p>
              We tie projects to KPIs up front, then iterate with you until efficiency, quality,
              and value outcomes are visible.
            </p>
          </article>
          <article>
            <p className="tag">Partnership</p>
            <h3>Hands-on collaboration</h3>
            <p>
              We work as an extension of your team through implementation, rollout, and long-term
              support.
            </p>
          </article>
        </div>
      </section>

      <section className="product section-reveal">
        <div className="product-copy">
          <p className="eyebrow">Product Spotlight</p>
          <h2>Chatbotz.co.za</h2>
          <p>
            A no-code AI chatbot platform built for fast deployment. Customize your assistant,
            connect your knowledge base, and launch support experiences without engineering
            overhead.
          </p>
          <a
            className="btn btn-primary"
            href="https://chatbotz.co.za"
            target="_blank"
            rel="noreferrer noopener"
          >
            Visit Chatbotz
          </a>
        </div>
        <img src="/assets/ai_agents.png" alt="AI product illustration" />
      </section>

      <ContactPanel />
    </>
  );
}

function AboutPage() {
  return (
    <>
      <section className="page-hero section-reveal">
        <p className="eyebrow">About DnD</p>
        <h1>Driving innovation with AI and software engineering</h1>
        <p>
          DnD Digital helps businesses adopt practical AI and modern software systems that improve
          performance, reduce costs, and scale with confidence.
        </p>
      </section>

      <section className="split-section section-reveal">
        <div>
          <h2>Our mission</h2>
          <p>
            Democratize advanced AI capabilities for organizations of any size by delivering
            focused, measurable solutions instead of abstract experimentation.
          </p>
          <ul className="bullet-list">
            <li>Purpose-driven problem framing</li>
            <li>Hands-on engineering with your team</li>
            <li>Clear performance and ROI tracking</li>
          </ul>
        </div>
        <img src="/assets/software.webp" alt="DnD team collaboration" />
      </section>

      <section className="metric-band section-reveal">
        <article>
          <h3>50+</h3>
          <p>Projects delivered across AI and software</p>
        </article>
        <article>
          <h3>100%</h3>
          <p>Client-first quality and support focus</p>
        </article>
        <article>
          <h3>24/7</h3>
          <p>Operational guidance when it matters</p>
        </article>
      </section>

      <section className="values section-reveal">
        <header className="section-head">
          <p className="eyebrow">Values</p>
          <h2>How we work</h2>
        </header>
        <div className="values-grid">
          <article>
            <h3>Purpose-driven</h3>
            <p>Every initiative is tied to business outcomes, not novelty.</p>
          </article>
          <article>
            <h3>Partnership</h3>
            <p>We collaborate as an extension of your internal team.</p>
          </article>
          <article>
            <h3>Technical excellence</h3>
            <p>Reliable architecture, secure foundations, and maintainable systems.</p>
          </article>
          <article>
            <h3>Practical implementation</h3>
            <p>Focused roadmaps and delivery plans that fit real constraints.</p>
          </article>
          <article>
            <h3>Transparency</h3>
            <p>Direct communication, clear scope, and honest progress reporting.</p>
          </article>
          <article>
            <h3>Continuous growth</h3>
            <p>Ongoing optimization as your operations and tools evolve.</p>
          </article>
        </div>
      </section>

      <ContactPanel />
    </>
  );
}

function ServicesPage() {
  return (
    <>
      <section className="page-hero section-reveal">
        <p className="eyebrow">Services</p>
        <h1>AI strategy, autonomous systems, and custom software delivery</h1>
        <p>
          We combine consulting and engineering execution to move from idea to deployed production
          systems without fragmentation.
        </p>
      </section>

      <section className="services section-reveal">
        <div className="card-grid">
          <article className="service-card">
            <img src="/assets/chatgpt_interface.webp" alt="Generative AI service" />
            <div>
              <h3>Generative AI & Agents</h3>
              <p>LLMs, RAG pipelines, and intelligent agents integrated into your workflows.</p>
              <Link className="btn btn-ghost" to="/services/generative-ai">
                Open page
              </Link>
            </div>
          </article>
          <article className="service-card">
            <img src="/assets/consulting.jpg" alt="Consulting service" />
            <div>
              <h3>AI Consulting & Strategy</h3>
              <p>Opportunity mapping, readiness assessments, governance, and rollout planning.</p>
              <Link className="btn btn-ghost" to="/services/consulting">
                Open page
              </Link>
            </div>
          </article>
          <article className="service-card">
            <img src="/assets/software.webp" alt="Software service" />
            <div>
              <h3>Bespoke Software Development</h3>
              <p>Tailored apps, integrations, and cloud-native engineering for scale.</p>
              <Link className="btn btn-ghost" to="/services/software">
                Open page
              </Link>
            </div>
          </article>
        </div>
      </section>

      <section className="timeline section-reveal">
        <header className="section-head">
          <p className="eyebrow">Delivery Model</p>
          <h2>How engagement works</h2>
        </header>
        <div className="timeline-grid">
          <article>
            <h3>1. Discover</h3>
            <p>Align on goals, systems, constraints, and measurable outcomes.</p>
          </article>
          <article>
            <h3>2. Architect</h3>
            <p>Design solution blueprints, data flows, and implementation scope.</p>
          </article>
          <article>
            <h3>3. Build</h3>
            <p>Ship in iterative milestones with testing, instrumentation, and QA.</p>
          </article>
          <article>
            <h3>4. Operate</h3>
            <p>Monitor adoption, performance, and continuous optimization.</p>
          </article>
        </div>
      </section>

      <ContactPanel />
    </>
  );
}

function ServiceDetailPage({ eyebrow, title, summary, image, features, stack }) {
  return (
    <>
      <section className="page-hero section-reveal">
        <p className="eyebrow">{eyebrow}</p>
        <h1>{title}</h1>
        <p>{summary}</p>
      </section>

      <section className="split-section section-reveal">
        <div>
          <h2>What we deliver</h2>
          <ul className="bullet-list">
            {features.map((feature) => (
              <li key={feature}>{feature}</li>
            ))}
          </ul>
        </div>
        <img src={image} alt={`${title} visual`} />
      </section>

      <section className="stack section-reveal">
        <header className="section-head">
          <p className="eyebrow">Technology</p>
          <h2>Platforms and tools</h2>
        </header>
        <div className="stack-list">
          {stack.map((item) => (
            <span key={item}>{item}</span>
          ))}
        </div>
      </section>

      <section className="cta-strip section-reveal">
        <h2>Ready to start this service?</h2>
        <div className="hero-actions">
          <Link className="btn btn-primary" to="/contact">
            Book a call
          </Link>
          <Link className="btn btn-ghost" to="/services">
            Back to services
          </Link>
        </div>
      </section>
    </>
  );
}

function ContactPanel() {
  return (
    <section className="contact section-reveal">
      <div>
        <p className="eyebrow">Let&apos;s Build</p>
        <h2>Ready to modernize your business with AI?</h2>
        <p>
          Start with a free 15-minute discovery call. We will review your goals and identify where
          AI or custom software can create measurable gains first.
        </p>
      </div>
      <div className="contact-actions">
        <a className="btn btn-primary" href="mailto:info@dndsoftware.com">
          info@dndsoftware.com
        </a>
        <a className="btn btn-ghost" href="tel:+1234567890">
          +1 (234) 567-890
        </a>
      </div>
    </section>
  );
}

function ContactPage() {
  return (
    <>
      <section className="page-hero section-reveal">
        <p className="eyebrow">Contact</p>
        <h1>Talk to DnD Digital</h1>
        <p>
          Reach out for a short discovery call. We will identify your highest impact AI and software
          opportunities and recommend practical next steps.
        </p>
      </section>
      <ContactPanel />
    </>
  );
}

function App() {
  return (
    <Routes>
      <Route element={<SiteLayout />}>
        <Route index element={<HomePage />} />
        <Route path="about" element={<AboutPage />} />
        <Route path="services" element={<ServicesPage />} />
        <Route
          path="services/generative-ai"
          element={
            <ServiceDetailPage
              eyebrow="Generative AI & Agents"
              title="Deploy intelligent systems that can reason, retrieve, and act"
              summary={
                'We design production-ready AI assistants and agents that integrate with your data, tools, and customer touchpoints for measurable operational improvements.'
              }
              image="/assets/chatgpt_interface.webp"
              features={[
                'RAG architecture and knowledge grounding',
                'Agent orchestration for multi-step workflows',
                'Fine-tuning and prompt system optimization',
                'Observability, guardrails, and quality monitoring',
              ]}
              stack={['OpenAI', 'Anthropic', 'Google', 'LangChain', 'LangFlow', 'n8n']}
            />
          }
        />
        <Route
          path="services/consulting"
          element={
            <ServiceDetailPage
              eyebrow="AI Consulting & Strategy"
              title="Design a roadmap that turns AI investment into business value"
              summary={
                'We help leadership teams identify viable opportunities, prioritize implementation, and align delivery with governance, compliance, and ROI expectations.'
              }
              image="/assets/consulting.jpg"
              features={[
                'AI readiness and opportunity assessments',
                'Use-case prioritization with ROI modeling',
                'Technology and vendor selection guidance',
                'Governance, risk, and change-management planning',
              ]}
              stack={['Strategy Workshops', 'Roadmaps', 'Governance Frameworks', 'Risk Controls']}
            />
          }
        />
        <Route
          path="services/software"
          element={
            <ServiceDetailPage
              eyebrow="Bespoke Software Development"
              title="Engineer modern products and platforms that scale with your business"
              summary={
                'From web platforms to cloud services and integrations, we build tailored software solutions that support your operating model and long-term growth.'
              }
              image="/assets/software.webp"
              features={[
                'Custom web and internal platform development',
                'API integrations and workflow automation',
                'Cloud-native architecture and DevOps pipelines',
                'Legacy modernization and performance optimization',
              ]}
              stack={[
                'React',
                'TypeScript',
                'Node.js',
                'Python',
                'AWS',
                'Docker',
                'PostgreSQL',
                'GraphQL',
              ]}
            />
          }
        />
        <Route path="contact" element={<ContactPage />} />
      </Route>
    </Routes>
  );
}

export default App;
